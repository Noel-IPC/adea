package com.adea.entrevista.controller;

import com.adea.entrevista.dto.Mensaje;
import com.adea.entrevista.dto.UsuarioDto;
import com.adea.entrevista.entity.Usuario;
import com.adea.entrevista.service.UsuarioService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuario")
@CrossOrigin
public class UsuarioController {

    @Autowired
    UsuarioService usuarioService;

    @GetMapping("/lista")
    public ResponseEntity<List<Usuario>> list(){
        List<Usuario> list = usuarioService.list();
        return new ResponseEntity<List<Usuario>>(list, HttpStatus.OK);
    }

    @GetMapping("/detalle/{login}")
    public ResponseEntity<Usuario> getByLogin(@PathVariable("login") String login){
        if (!usuarioService.existsByLogin(login))
            return new ResponseEntity(new Mensaje("No existe"), HttpStatus.NOT_FOUND);
        Usuario u = usuarioService.getOne(login).get();
        return new ResponseEntity(u, HttpStatus.OK);
    }

    @GetMapping("/detalle/{nombre}")
    public ResponseEntity<Usuario> getByNombre(@PathVariable("nombre") String nombre){
        if (!usuarioService.existsByNombre(nombre))
            return new ResponseEntity(new Mensaje("No existe"), HttpStatus.NOT_FOUND);
        Usuario u = usuarioService.getByNombre(nombre).get();
        return new ResponseEntity(u, HttpStatus.OK);
    }

    @GetMapping("/detalle/{email}")
    public ResponseEntity<Usuario> getByEmail(@PathVariable("email") String email){
        if (!usuarioService.existsByNombre(email))
            return new ResponseEntity(new Mensaje("No existe"), HttpStatus.NOT_FOUND);
        Usuario u = usuarioService.getByEmail(email).get();
        return new ResponseEntity(u, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/crear")
    public ResponseEntity<?> create(@RequestBody UsuarioDto uDto){
        if (usuarioService.existsByLogin(uDto.getLogin()))
            return new ResponseEntity(new Mensaje("El usuario ya existe"), HttpStatus.NOT_FOUND);
        if (StringUtils.isBlank(uDto.getLogin()))
            return new ResponseEntity(new Mensaje("El login es obligatorio"), HttpStatus.BAD_REQUEST);
        if (StringUtils.isBlank(uDto.getPassword()))
            return new ResponseEntity(new Mensaje("El password es obligatorio"), HttpStatus.BAD_REQUEST);
        if (StringUtils.isBlank(uDto.getNombre()))
            return new ResponseEntity(new Mensaje("El nombre es obligatorio"), HttpStatus.BAD_REQUEST);
        if (uDto.getCliente()>0 || uDto.getCliente()==null)
            return new ResponseEntity(new Mensaje("El cliente debe ser mayor que cero"), HttpStatus.BAD_REQUEST);
        Usuario u = new Usuario(uDto.getLogin(), uDto.getPassword(), uDto.getNombre(), uDto.getCliente(), uDto.getEmail(), uDto.getFechaalta(),
                uDto.getFechabaja(), uDto.getStatus(), uDto.getIntentos(), uDto.getFecharevocado(), uDto.getFecha_vigencia(), uDto.getNo_acceso(),
                uDto.getApellido_paterno(), uDto.getApellido_materno(), uDto.getArea(), uDto.getFechamodifcacion());

        usuarioService.save(u);
        return new ResponseEntity(new Mensaje("Usuario creado"), HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/actualizar/{login}")
    public ResponseEntity<?> update(@PathVariable("login") String login, @RequestBody UsuarioDto uDto){
        if (!usuarioService.existsByLogin(login))
            return new ResponseEntity(new Mensaje("No existe el usuario"), HttpStatus.NOT_FOUND);
        if (StringUtils.isBlank(uDto.getLogin()))
            return new ResponseEntity(new Mensaje("El login es obligatorio"), HttpStatus.BAD_REQUEST);
        if (StringUtils.isBlank(uDto.getPassword()))
            return new ResponseEntity(new Mensaje("El password es obligatorio"), HttpStatus.BAD_REQUEST);
        if (StringUtils.isBlank(uDto.getNombre()))
            return new ResponseEntity(new Mensaje("El nombre es obligatorio"), HttpStatus.BAD_REQUEST);
        if (uDto.getCliente()>0 || uDto.getCliente()==null)
            return new ResponseEntity(new Mensaje("El cliente debe ser mayor que cero"), HttpStatus.BAD_REQUEST);
        Usuario u = new Usuario(uDto.getLogin(), uDto.getPassword(), uDto.getNombre(), uDto.getCliente(), uDto.getEmail(), uDto.getFechaalta(),
                uDto.getFechabaja(), uDto.getStatus(), uDto.getIntentos(), uDto.getFecharevocado(), uDto.getFecha_vigencia(), uDto.getNo_acceso(),
                uDto.getApellido_paterno(), uDto.getApellido_materno(), uDto.getArea(), uDto.getFechamodifcacion());

        usuarioService.save(u);
        return new ResponseEntity(new Mensaje("Usuario creado"), HttpStatus.CREATED);
    }
}
