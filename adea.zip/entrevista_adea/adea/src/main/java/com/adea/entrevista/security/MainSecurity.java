package com.adea.entrevista.security;

public class MainSecurity {
}
