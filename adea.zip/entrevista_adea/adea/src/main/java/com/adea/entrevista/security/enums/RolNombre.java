package com.adea.entrevista.security.enums;

public enum RolNombre {

    ROLE_ADMIN, ROLE_USER
    
}
