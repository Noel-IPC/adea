package com.adea.entrevista.service;

import com.adea.entrevista.entity.Usuario;
import com.adea.entrevista.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UsuarioService {

    @Autowired
    UsuarioRepository usuarioRepository;

    public List<Usuario> list(){
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> getOne(String login){
        return usuarioRepository.findByLogin(login);
    }

    public Optional<Usuario> getByNombre(String nombre){
        return usuarioRepository.findByNombre(nombre);
    }

    public Optional<Usuario> getByEmail(String login){
     return usuarioRepository.findByLogin(login);
    }

    public void save(Usuario usuario){
        usuarioRepository.save(usuario);
    }

    public void delete(String login){
        usuarioRepository.deleteById(login);
    }

    public boolean existsByLogin(String login){
        return usuarioRepository.existsByLogin(login);
    }

    public boolean existsByNombre(String nombre){
        return usuarioRepository.existsByNombre(nombre);
    }

    public boolean existsByEmail(String email){
        return usuarioRepository.existsByEmail(email);
    }
}
