package com.adea.entrevista.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "USUARIO")
public class Usuario implements Serializable {

    private final static Long serialUID = 1L;

    @Id
    @Column(name = "LOGIN")
    private String login;

    @Column(name = "PASSWORD")
    private String password;

    @Column(name = "NOMBRE")
    private String nombre;

    @Column(name = "CLIENTE")
    private Float cliente;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "FECHAALTA")
    @Temporal(TemporalType.DATE)
    private Date fechaalta;

    @Column(name = "FECHABAJA")
    @Temporal(TemporalType.DATE)
    private Date fechabaja;

    @Column(name = "STATUS")
    private Character status;

    @Column(name = "INTENTOS")
    private Float intentos;

    @Column(name = "FECHAREVOCADO")
    @Temporal(TemporalType.DATE)
    private Date fecharevocado;

    @Column(name = "FECHA_VIGENCIA")
    @Temporal(TemporalType.DATE)
    private Date fecha_vigencia;

    @Column(name = "NO_ACCESO")
    private Integer no_acceso;

    @Column(name = "APELLIDO_PATERNO")
    private String apellido_paterno;

    @Column(name = "APELLIDO_MATERNO")
    private String apellido_materno;

    @Column(name = "AREA")
    private Byte area;

    @Column(name = "FECHAMODIFICACION")
    @Temporal(TemporalType.DATE)
    private Date fechamodifcacion;

    public Usuario() {
    }

    public Usuario(String login, String password, String nombre, Float cliente, String email, Date fechaalta, Date fechabaja, Character status, Float intentos, Date fecharevocado, Date fecha_vigencia, Integer no_acceso, String apellido_paterno, String apellido_materno, Byte area, Date fechamodifcacion) {
        this.login = login;
        this.password = password;
        this.nombre = nombre;
        this.cliente = cliente;
        this.email = email;
        this.fechaalta = fechaalta;
        this.fechabaja = fechabaja;
        this.status = status;
        this.intentos = intentos;
        this.fecharevocado = fecharevocado;
        this.fecha_vigencia = fecha_vigencia;
        this.no_acceso = no_acceso;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.area = area;
        this.fechamodifcacion = fechamodifcacion;
    }

    @Override
    public String toString() {
        return "UsuarioService{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", nombre='" + nombre + '\'' +
                ", cliente=" + cliente +
                ", email='" + email + '\'' +
                ", fechaalta=" + fechaalta +
                ", fechabaja=" + fechabaja +
                ", status=" + status +
                ", intentos=" + intentos +
                ", fecharevocado=" + fecharevocado +
                ", fecha_vigencia=" + fecha_vigencia +
                ", no_acceso=" + no_acceso +
                ", apellido_paterno='" + apellido_paterno + '\'' +
                ", apellido_materno='" + apellido_materno + '\'' +
                ", area=" + area +
                ", fechamodifcacion=" + fechamodifcacion +
                '}';
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Float getCliente() {
        return cliente;
    }

    public void setCliente(Float cliente) {
        this.cliente = cliente;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getFechaalta() {
        return fechaalta;
    }

    public void setFechaalta(Date fechaalta) {
        this.fechaalta = fechaalta;
    }

    public Date getFechabaja() {
        return fechabaja;
    }

    public void setFechabaja(Date fechabaja) {
        this.fechabaja = fechabaja;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public Float getIntentos() {
        return intentos;
    }

    public void setIntentos(Float intentos) {
        this.intentos = intentos;
    }

    public Date getFecharevocado() {
        return fecharevocado;
    }

    public void setFecharevocado(Date fecharevocado) {
        this.fecharevocado = fecharevocado;
    }

    public Date getFecha_vigencia() {
        return fecha_vigencia;
    }

    public void setFecha_vigencia(Date fecha_vigencia) {
        this.fecha_vigencia = fecha_vigencia;
    }

    public Integer getNo_acceso() {
        return no_acceso;
    }

    public void setNo_acceso(Integer no_acceso) {
        this.no_acceso = no_acceso;
    }

    public String getApellido_paterno() {
        return apellido_paterno;
    }

    public void setApellido_paterno(String apellido_paterno) {
        this.apellido_paterno = apellido_paterno;
    }

    public String getApellido_materno() {
        return apellido_materno;
    }

    public void setApellido_materno(String apellido_materno) {
        this.apellido_materno = apellido_materno;
    }

    public Byte getArea() {
        return area;
    }

    public void setArea(Byte area) {
        this.area = area;
    }

    public Date getFechamodifcacion() {
        return fechamodifcacion;
    }

    public void setFechamodifcacion(Date fechamodifcacion) {
        this.fechamodifcacion = fechamodifcacion;
    }
}
