package com.adea.entrevista.dto;

import javax.validation.constraints.NotNull;
import java.util.Date;

public class UsuarioDto {

    @NotNull(message = "Este campo no puede ser nulo")
    private String login;
    @NotNull(message = "El password no puede ser nulo")
    private String password;
    @NotNull(message = "El nombre no puede ser nulo")
    private String nombre;
    @NotNull(message = "El cliente no puede ser nulo")
    private Float cliente;

    private String email;

    @NotNull(message = "La fecha de alta no puede ser nulo")
    private Date fechaalta;

    private Date fechabaja;

    @NotNull(message = "El status no puede ser nulo")
    private Character status;
    @NotNull(message = "Este campo no puede ser nulo")
    private Float intentos;

    private Date fecharevocado;
    private Date fecha_vigencia;
    private Integer no_acceso;
    private String apellido_paterno;
    private String apellido_materno;
    private Byte area;

    @NotNull(message = "Este campo no puede ser nulo")
    private Date fechamodifcacion;

    public UsuarioDto() {
    }

    public UsuarioDto(String login, String password, String nombre, Float cliente, String email, Date fechaalta, Date fechabaja, Character status, Float intentos, Date fecharevocado, Date fecha_vigencia, Integer no_acceso, String apellido_paterno, String apellido_materno, Byte area, Date fechamodifcacion) {
        this.login = login;
        this.password = password;
        this.nombre = nombre;
        this.cliente = cliente;
        this.email = email;
        this.fechaalta = fechaalta;
        this.fechabaja = fechabaja;
        this.status = status;
        this.intentos = intentos;
        this.fecharevocado = fecharevocado;
        this.fecha_vigencia = fecha_vigencia;
        this.no_acceso = no_acceso;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.area = area;
        this.fechamodifcacion = fechamodifcacion;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Float getCliente() {
        return cliente;
    }

    public void setCliente(Float cliente) {
        this.cliente = cliente;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getFechaalta() {
        return fechaalta;
    }

    public void setFechaalta(Date fechaalta) {
        this.fechaalta = fechaalta;
    }

    public Date getFechabaja() {
        return fechabaja;
    }

    public void setFechabaja(Date fechabaja) {
        this.fechabaja = fechabaja;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public Float getIntentos() {
        return intentos;
    }

    public void setIntentos(Float intentos) {
        this.intentos = intentos;
    }

    public Date getFecharevocado() {
        return fecharevocado;
    }

    public void setFecharevocado(Date fecharevocado) {
        this.fecharevocado = fecharevocado;
    }

    public Date getFecha_vigencia() {
        return fecha_vigencia;
    }

    public void setFecha_vigencia(Date fecha_vigencia) {
        this.fecha_vigencia = fecha_vigencia;
    }

    public Integer getNo_acceso() {
        return no_acceso;
    }

    public void setNo_acceso(Integer no_acceso) {
        this.no_acceso = no_acceso;
    }

    public String getApellido_paterno() {
        return apellido_paterno;
    }

    public void setApellido_paterno(String apellido_paterno) {
        this.apellido_paterno = apellido_paterno;
    }

    public String getApellido_materno() {
        return apellido_materno;
    }

    public void setApellido_materno(String apellido_materno) {
        this.apellido_materno = apellido_materno;
    }

    public Byte getArea() {
        return area;
    }

    public void setArea(Byte area) {
        this.area = area;
    }

    public Date getFechamodifcacion() {
        return fechamodifcacion;
    }

    public void setFechamodifcacion(Date fechamodifcacion) {
        this.fechamodifcacion = fechamodifcacion;
    }
}
