create table usuario
(
    login VARCHAR2(20) NOT NULL CONSTRAINT PK_LOGIN PRIMARY KEY,
    password VARCHAR2(30) NOT NULL,
    nombre VARCHAR2(50) NOT NULL,
    cliente FLOAT NOT NULL,
    email VARCHAR2(50) NULL,
    fechaalta DATE DEFAULT sysdate NOT NULL,
    fechabaja DATE NULL,
    status CHAR(1) DEFAULT 'A',
    intentos FLOAT DEFAULT 0 NOT NULL,
    fecharevocado DATE NULL,
    fecha_vigencia DATE NULL,
    no_acceso INTEGER NULL,
    apellido_paterno VARCHAR2(50) NULL,
    apellido_materno VARCHAR2(50) NULL,
    area NUMBER(4) NULL,
    fechamodifcacion DATE DEFAULT sysdate NOT NULL
);
