package com.adea.entrevista;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntrevistaApplication {

    public static void main(String[] args) {
        SpringApplication.run(EntrevistaApplication.class, args);
    }

}
